//@dart=2.9
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../Test List/test_list_items.dart';

class HomeImageSlider extends StatefulWidget {
  const HomeImageSlider({Key key}) : super(key: key);

  @override
  State<HomeImageSlider> createState() => _HomeImageSliderState();
}

class _HomeImageSliderState extends State<HomeImageSlider> {

  final List<String> sliderBanners = [
    'assets/Image Slider/banner_1.jpg',
    'assets/Image Slider/banner_2.jpg',
    'assets/Image Slider/banner_3.jpg',
    'assets/Image Slider/01-Banner.png',
    'assets/Image Slider/02-Banner.png',
    'assets/Image Slider/03-Banner.png',
  ];

  @override
  Widget build(BuildContext context) {  
    return Container(
      width: MediaQuery.of(context).size.width.w,
      height: MediaQuery.of(context).size.height / 6.h,
      //color: Colors.green,
      child: CarouselSlider.builder(
        options: CarouselOptions(
          viewportFraction: 0.8,
          initialPage: 0,
          enableInfiniteScroll: true,
          reverse: false,
          autoPlay: true,
          autoPlayInterval: Duration(seconds: 3),
          autoPlayAnimationDuration: Duration(milliseconds: 2000),
          autoPlayCurve: Curves.fastOutSlowIn,
          enlargeCenterPage: true,
          enlargeFactor: 0.1,
          scrollDirection: Axis.horizontal,
        ),
        itemCount: sliderBanners.length,
        itemBuilder: (BuildContext context, int itemIndex, int pageViewIndex){
          return Container(
            width: MediaQuery.of(context).size.width.w,
            height: MediaQuery.of(context).size.height / 7.h,
            //padding: EdgeInsets.all(5),
            //color: Colors.yellow,
            child: InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>TestListItems()));
              },
              child: Image(image: AssetImage("${sliderBanners[itemIndex]}"),fit: BoxFit.fill,)),
          );
        },
      ),
    );
  }
}
