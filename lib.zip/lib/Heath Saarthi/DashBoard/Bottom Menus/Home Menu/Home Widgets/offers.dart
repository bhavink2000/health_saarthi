//@dart=2.9
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../App Helper/Frontend Helper/Font & Color Helper/font_&_color_helper.dart';
import '../Test List/test_list_items.dart';

class HomeOffers extends StatefulWidget {
  const HomeOffers({Key key}) : super(key: key);

  @override
  State<HomeOffers> createState() => _HomeOffersState();
}

class _HomeOffersState extends State<HomeOffers> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width.w,
      height: MediaQuery.of(context).size.height / 7.5.h,
      color: Colors.grey.withOpacity(0.1),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(15, 10, 0, 0),
            child: Text("Today's Deal",style: TextStyle(fontFamily: FontType.MontserratMedium,fontSize: 14.sp,letterSpacing: 0.5,fontWeight: FontWeight.bold),),
          ),
          Container(
            width: MediaQuery.of(context).size.width.w,
            height: MediaQuery.of(context).size.height / 11.h,
            //color: Colors.blue,
            padding: const EdgeInsets.fromLTRB(5, 2, 5, 0),
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              itemCount: 5,
              itemBuilder: (context, index){
                return Padding(
                  padding: EdgeInsets.fromLTRB(5.w, 7.h, 5.w, 5.h),
                  child: InkWell(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>TestListItems()));
                    },
                    child: Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                      color: Colors.white,
                      child: Container(
                        width: MediaQuery.of(context).size.width / 1.35.w,
                        height: MediaQuery.of(context).size.height / 20.h,
                        //padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            gradient: LinearGradient(
                              begin: Alignment.topRight,
                              end: Alignment.bottomLeft,
                              colors: [
                                hsPrime.withOpacity(1),
                                hsPrime.withOpacity(0.7),
                              ],
                            ),
                            border: Border.all(color: hsPrime,width: 0.2)
                            //color: Colors.white
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(10, 5, 5, 5),
                              child: Container(
                                  child: Image(
                                      image: AssetImage("assets/Home/discount.png"),
                                  )
                              ),
                            ),
                            Expanded(child: Text("Flat 20% off on All Blood test Booking",style: TextStyle(fontFamily: FontType.MontserratRegular,fontSize: 12,color: Colors.white),)),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
