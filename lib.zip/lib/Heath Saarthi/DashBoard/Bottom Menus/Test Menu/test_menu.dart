//@dart=2.9
// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:search_choices/search_choices.dart';
import '../../../App Helper/Frontend Helper/Font & Color Helper/font_&_color_helper.dart';
import 'thank_you_msg.dart';

class TestMenu extends StatefulWidget {
  const TestMenu({Key key}) : super(key: key);

  @override
  State<TestMenu> createState() => _TestMenuState();
}

class _TestMenuState extends State<TestMenu> {

  bool addVendor = false;
  File fileManger;
  final mobileNo = TextEditingController();
  final emailId = TextEditingController();
  final address = TextEditingController();
  final pinCode = TextEditingController();
  final colletionDate = TextEditingController();
  final remark = TextEditingController();

  List<String> states = ['Gujarat', 'Punjab', 'Pune'];
  List<String> cities = ['Rajkot', 'Goa', 'Diu'];
  List<String> areaName = ['area One', 'area Two', 'area Three'];
  String selectedState;
  String selectedCity;
  String selectedArea;
  String selectedHospital;
  List<String> hospitalName = [
    '123456789',
    '234567891',
    '345678912',
    '456789123',
    '567891234',
    '678912345',
  ];
  final pAge = TextEditingController();
  final pDob = TextEditingController();
  final pName = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 5, 10, 5),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(height: 20,width: 2,color: hsTwo),
                    const SizedBox(width: 5,),
                    Text("Booking Form",style: TextStyle(fontFamily: FontType.MontserratMedium,color: hsOne,letterSpacing: 1,fontSize: 18)),
                    const Spacer(),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Card(
                  elevation: 5,
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                  child: Container(
                    height: MediaQuery.of(context).size.height / 12.h,
                    decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.all(Radius.circular(10))),
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
                    child: SearchChoices.single(
                      dropDownDialogPadding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                      items: hospitalName.map((member) {
                        return DropdownMenuItem<String>(
                          value: member,
                          child: Text(member),
                        );
                      }).toList(),
                      value: selectedHospital,
                      padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                      style: const TextStyle(fontFamily: FontType.MontserratMedium,fontSize: 15,letterSpacing: 1,color: Colors.black87),
                      hint: "Select Mobile Number",
                      searchHint: "Select Number",
                      onChanged: (value) {
                        setState(() {
                          selectedHospital = value;
                        });
                      },
                      isExpanded: true,
                    ),
                  ),
                ),
              ),
              showTextField('Patient Name', pName,Icons.person),
              showTextField('Patient Age', pAge,Icons.view_agenda),
              showTextField('DOB', pAge,Icons.calendar_month_rounded),
              showTextField('Email', emailId,Icons.email),
              showTextField('Address', address,Icons.location_city),
              SizedBox(height: 10.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                      width: MediaQuery.of(context).size.width / 2.5.w,
                      height: MediaQuery.of(context).size.height / 18.h,
                      child: DropdownButtonFormField<String>(
                        value: selectedState,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.fromLTRB(10, 2, 5, 2),
                          focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              borderRadius: BorderRadius.circular(15)
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              borderRadius: BorderRadius.circular(15)
                          ),
                          hintText: 'State',
                          hintStyle: const TextStyle(
                            color: Colors.black54,
                            fontFamily: FontType.MontserratRegular,
                            fontSize: 14,
                          ),
                        ),
                        onChanged: (newValue) {
                          selectedState = newValue;
                        },
                        items: states.map<DropdownMenuItem<String>>((String state) {
                          return DropdownMenuItem<String>(
                            value: state,
                            child: Text(state),
                          );
                        }).toList(),
                      )
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width / 2.5.w,
                    height: MediaQuery.of(context).size.height / 18.h,
                    child: DropdownButtonFormField<String>(
                      value: selectedCity,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.fromLTRB(10, 2, 5, 2),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                            borderRadius: BorderRadius.circular(15)
                        ),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                            borderRadius: BorderRadius.circular(15)
                        ),
                        hintText: 'City',
                        hintStyle: const TextStyle(
                          color: Colors.black54,
                          fontFamily: FontType.MontserratRegular,
                          fontSize: 14,
                        ),
                      ),
                      onChanged: (newValue) {
                        selectedCity = newValue;
                      },
                      items: cities.map<DropdownMenuItem<String>>((String city) {
                        return DropdownMenuItem<String>(
                          value: city,
                          child: Text(city),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                      width: MediaQuery.of(context).size.width / 2.5.w,
                      height: MediaQuery.of(context).size.height / 18.h,
                      child: DropdownButtonFormField<String>(
                        value: selectedArea,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.fromLTRB(10, 2, 5, 2),
                          focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              borderRadius: BorderRadius.circular(15)
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              borderRadius: BorderRadius.circular(15)
                          ),
                          hintText: 'Area',
                          hintStyle: const TextStyle(
                            color: Colors.black54,
                            fontFamily: FontType.MontserratRegular,
                            fontSize: 14,
                          ),
                        ),
                        onChanged: (newValue) {
                          selectedState = newValue;
                        },
                        items: areaName.map<DropdownMenuItem<String>>((String state) {
                          return DropdownMenuItem<String>(
                            value: state,
                            child: Text(state),
                          );
                        }).toList(),
                      )
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width / 2.5.w,
                    height: MediaQuery.of(context).size.height / 15.h,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
                      child: TextField(
                        controller: pinCode,
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.fromLTRB(10, 2, 5, 2),
                          focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              borderRadius: BorderRadius.circular(15)
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              borderRadius: BorderRadius.circular(15)
                          ),
                          hintText: 'Pincode',
                          hintStyle: const TextStyle(
                              color: Colors.black54,
                              fontFamily: FontType.MontserratRegular,
                              fontSize: 14
                          ),
                          prefixIcon: Icon(Icons.pin, color: hsBlack,size: 20),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              showTextField('Collection Date', colletionDate,Icons.pin),
              showTextField('Remark', remark,Icons.markunread_mailbox),

              Padding(
                padding: const EdgeInsets.fromLTRB(40, 10, 40, 20),
                child: InkWell(
                  onTap: (){
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      backgroundColor: hsOne,
                      content: const Text("Your booking Is Confirm",style: TextStyle(fontFamily: FontType.MontserratRegular,color: Colors.white),),
                    ));
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>ThankYouPage()));
                  },
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(15),color: hsTwo),
                    child: Text("Processed",style: TextStyle(fontFamily: FontType.MontserratRegular,color: Colors.white,fontSize: 18.sp,letterSpacing: 1)),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget showTextField(var lebal, TextEditingController controller, IconData iconData){
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 5),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.all(hsPaddingM),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
              borderRadius: BorderRadius.circular(15)
          ),
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
              borderRadius: BorderRadius.circular(15)
          ),
          hintText: '$lebal',
          hintStyle: const TextStyle(
              color: Colors.black54,
              fontFamily: FontType.MontserratRegular,
              fontSize: 14
          ),
          prefixIcon: Icon(iconData, color: hsBlack,size: 20),
        ),
      ),
    );
  }
}
