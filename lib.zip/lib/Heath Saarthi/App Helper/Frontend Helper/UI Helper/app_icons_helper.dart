// ignore_for_file: non_constant_identifier_names

import 'package:flutter/cupertino.dart';

class AppIcons{
  AssetImage HHome = const AssetImage("assets/home.png");
  AssetImage HBookNow = const AssetImage("assets/book_now.png");
  AssetImage HRecord = const AssetImage("assets/record.png");
  AssetImage HProfile = const AssetImage("assets/profile.png");
  AssetImage Menu = const AssetImage("assets/menu.png");
}