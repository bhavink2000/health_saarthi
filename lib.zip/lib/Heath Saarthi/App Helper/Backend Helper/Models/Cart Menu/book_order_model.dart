class BookOrderModel{
  final int status;
  final int isApplyPromo;
  final int applyPromo;
  final int netAmount;
  final int grossAmount;
  final int discountAmount;

  BookOrderModel(this.status, this.isApplyPromo, this.applyPromo, this.netAmount,this.grossAmount,this.discountAmount);
}