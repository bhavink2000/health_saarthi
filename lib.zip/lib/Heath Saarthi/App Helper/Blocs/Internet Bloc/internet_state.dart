abstract class InternetState{}

class InternetIntialState extends InternetState{}

class InternetGainedState extends InternetState{}

class InternetLostState extends InternetState{}

